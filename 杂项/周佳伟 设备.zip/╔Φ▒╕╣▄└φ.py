#!/usr/bin/env python
# -*- coding: utf-8 -*-

import pymysql

# 设置参数
conn = pymysql.connect(
    host='127.0.0.1',
    port=3306,
    user='root',
    password='root',
    db='test',
    charset='utf8'
)
cur = conn.cursor()
actionlist = ['n', 'u', 'd', 'f']
dict = {'i': 'deviceid', 'n': 'device_name', 'u': 'device_user', 'o': 'device_office'}

# 定义创建函数
def new():  # 新建
    a = int(input('Please input the deviceID your want to add:\n'))
    b = input('Please input the deviceName your want to add:\n')
    c = input('Please input the deviceUser your want to add:\n')
    d = input('Please input the deviceOffice your want to add:\n')
    sql = cur.execute("insert into IPDB values(%d,'%s','%s','%s')" %(a, b, c, d))


def find():  # 查询
    x = input('''Which method do you want to query?
ID: i, Name: n, User: u, Office: o\n''')
    while 1:
        if x in dict:
            y = input('Please enter the data you want to query:\n')
            if x != 'i':
                sql = cur.execute("select * from IPDB where %s = '%s'" % (dict[x], y))
            else:
                sql = cur.execute("select * from IPDB where %s = %d" % (dict[x], int(y)))
            break
        else:
            x = input('Your order input wrong, Please try again:\n')
    info = cur.fetchmany(sql)
    for i in info:
        print(i)
    print('query completed!')


def modify(n):  # 修改
    if n == 'u':
        x = input('''Which data do you want to updata?
ID: i, Name: n, User: u, Office: o\n''')
        while 1:
            if x in dict:
                y = input('Please enter the data you want to update:\n')
                z = input('Please enter your modified data:\n')
                if x != 'i':
                    sql = cur.execute("update IPDB set %s = '%s' where %s = '%s'" % (dict[x], z, dict[x], y))
                else:
                    sql = cur.execute("update IPDB set %s = %d where %s = %d" % (dict[x], int(z), dict[x], int(y)))
                break
            else:
                x = input('Your order input wrong, Please try again:\n')
    else:
        z = input('Delete row or specify property:\nRow: r, Property: p\n')
        x = input('''Which method do you want to delete?
ID: i, Name: n, User: u, Office: o\n''')
        while 1:
            if z == 'r':
                while 1:
                    if x in dict:
                        y = input('Please enter the data you want to delete:\n')
                        if x != 'i':
                            sql = cur.execute("delete from IPDB where %s = '%s'" % (dict[x], y))
                        else:
                            sql = cur.execute("delete from IPDB where %s = %d" % (dict[x], int(y)))
                        break
                    else:
                        x = input('Your order input wrong, Please try again:\n')
                break
            elif z == 'p':
                while 1:
                    if x in dict:
                        y = input('Please enter the data you want to delete:\n')
                        if x != 'i':
                            sql = cur.execute("update IPDB set %s = ''where %s = '%s'" % (dict[x], dict[x], y))
                        else:
                            sql = cur.execute("update IPDB set %s = NULL where %s = %d" % (dict[x], dict[x], int(y)))
                        break
                break
            else:
                z = input('Your order input wrong, Please try again:\n')


while 1:
    action = input('''Please input your what do you want to do:
new: n, find: f, update: u, delete: d, exit: e\n''')
    while action != 'e':
        if action == 'n':
            new()
            break
        elif action == 'f':
            find()
            break
        elif action == 'u' or action == 'd':
            modify(action)
            break
        else:
            action = input('Your order is wrong, Pleas try again:\n')
    if action == 'e':
        break
